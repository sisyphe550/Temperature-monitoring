// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "RuntimeLifecycleReview", platforms: [.macOS(.v15)], targets: [
    .systemLibrary(name: "CSQLite", path: "Sources/CSQLite"),
    .target(name: "TemperatureCore", dependencies: ["CSQLite"], resources: [.copy("Resources/defaults-v1.json"), .copy("Resources/first-profile-v1.json"), .copy("Resources/schema-v1.sql")]),
    .target(name: "SensorRuntime", dependencies: ["TemperatureCore"]),
    .target(name: "TemperaturePresentation", dependencies: ["TemperatureCore"]),
    .executableTarget(name: "AppRuntimeHarness", dependencies: ["TemperatureCore", "SensorRuntime", "TemperaturePresentation"]),
])
