public enum TemperatureCoreModule {}
