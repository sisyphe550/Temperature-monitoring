# Independent runtime lifecycle reproduction

The harness includes the exact runtime/coordinator source tested for startup, suspend and shutdown cancellation. All clients/clocks are synthetic; this is not hardware or OS sleep evidence. FinalSourceSnapshot contains the later final runtime (1Hz history change only) and the four reviewed files; source-manifest.json records both hashes.

From this directory:

```bash
swift build --scratch-path /tmp/temperature-runtime-review-reproduction-build --product AppRuntimeHarness
/tmp/temperature-runtime-review-reproduction-build/arm64-apple-macosx/debug/AppRuntimeHarness stop-cancelled-wake
```

Other verified entries: `immediate`, `discover-held`, `same-mainactor-job`, `stop-before-admission`, `stop-discover-held`. Each CLI invocation should exit0; the RED/initial results are retained in Evidence. No GUI or real SensorWorker is launched. Commands run only when explicitly authorized; do not run a second hardware/long UI test from this package.

Build may require local SwiftPM cache permissions. The review run used an independent /tmp scratch directory and did not touch repository .build.
